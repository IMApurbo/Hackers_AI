# hackers-ai-cli

A Node/TypeScript, npm-installable terminal agent with a Claude-Code-style UI
(Ink): scrolling transcript, boxed multi-line input, tool-call cards, a
spinner, and inline y/n confirmation before any shell command runs.

It talks to the **same local proxy** your original Python script used —
an Anthropic-Messages-shaped HTTP server at `http://localhost:8765/v1/messages`
(override with `HACKERS_AI_PROXY=<url>` or `/proxy <url>` inside the app).
If you don't have that proxy running yet, this CLI will just print a warning
at startup and let you fix the URL — it won't crash.

## Install

```bash
cd hackers-ai-cli
npm install
npm run build
npm link          # makes `hackers-ai` available globally
```

Then from anywhere:

```bash
hackers-ai
```

Or without linking:

```bash
npm start
```

## Config

- `HACKERS_AI_PROXY` — proxy base URL (default `http://localhost:8765`)
- `HACKERS_AI_MODEL` — model name sent to the proxy (default `deepseek-chat`)
- Settings you change with `/model` or `/proxy` inside the app are saved to
  your OS config dir (via `conf`) and persist across restarts.

## Permission modes

- **`auto` (default)** — `run_shell` executes immediately, no prompt. Same idea
  as Claude Code's "bypass permissions" mode.
- **`manual`** — every `run_shell` call shows a yellow y/n confirmation box
  before it runs.

Set it at launch:

```bash
hackers-ai --mode manual   # or: hackers-ai --manual
hackers-ai --mode auto     # or: hackers-ai --auto (default, can be omitted)
```

or toggle it mid-session with `/mode auto` / `/mode manual`.

## Slash commands

- `/help` — list commands
- `/clear` — clear the transcript and reset the agent's context
- `/mode auto|manual` — toggle whether `run_shell` needs confirmation
- `/model <name>` — switch model (persisted, takes effect on restart)
- `/proxy <url>` — switch proxy URL (persisted, takes effect on restart)
- `/exit` — quit

## Keys

- `Enter` — submit
- `Ctrl+J` — insert a newline without submitting
- `Esc` — interrupt the current turn while the agent is thinking/running
- `Up` / `Down` — walk through previous inputs (when the input box is empty)
- `Ctrl+U` — clear the current input line

## @-file mentions

Type `@` anywhere in the input to open a file picker (like Claude Code's):
it fuzzy-matches files under the current working directory (skipping
`node_modules`, `.git`, `dist`, `build`, dotfiles) as you type, `↑`/`↓` to
move, `Tab` or `Enter` to insert the path, `Esc` to keep typing without
inserting. The agent's system prompt tells the model to `read_file` any
`@path` token it sees in your message before responding.

## Parallel tool calls

When the model batches several independent tool calls into one turn (e.g.
reading three files, or running two unrelated shell commands), they now run
concurrently with `Promise.all` instead of one-at-a-time — same idea as
Claude Code executing independent tool calls in parallel. Results are still
matched back up and reported to the model in the original call order. In
`manual` permission mode, if more than one `run_shell` call needs your y/n
confirmation at the same time, they queue and are shown one at a time (only
one confirmation box can be on screen).

## Markdown and pasting

- Assistant replies are rendered as markdown (bold, headers, lists, fenced
  code blocks with syntax highlighting) instead of raw text.
- Pasting more than ~400 characters or any multi-line text into the input
  box collapses it into a placeholder like `[Pasted text: 40 lines, 210
  words #1]` — same behavior as the original script — and the full text is
  swapped back in automatically right before it's sent.
- Long tool output (long `run_shell` stdout, big file reads, etc.) is shown
  as a short preview in the transcript with a path to a log file holding
  the full text — the model itself always gets the complete output, only
  the terminal view is trimmed.

## What's implemented vs. what's carried over conceptually

This is a **full rewrite**, not a line-for-line port of the 5,000+ line
Python original — that file also contains a SQLite memory store, a Telegram
bot bridge, an MCP client, a user-profile "improve" mode, and a lot of
box-drawing terminal-width math that a proper Ink UI replaces outright.
What's here is the part you asked to rebuild — the Claude-Code-style agent
UI and its core loop — done properly in TypeScript:

- **Agent loop** (`src/core/agent.ts`) — same shape as the original's
  `ask_agentic`: send messages + tool schemas to the proxy, execute any
  `tool_use` blocks, feed `tool_result`s back, repeat until a plain text
  answer, capped at 30 turns.
- **Tools** (`src/core/tools.ts`) — `run_shell` (with an inline y/n confirm,
  like the original), `read_file`, `write_file`, `edit_file`, `grep`,
  `glob`, `web_fetch`, `ask_user`, `update_todos`, `notify_user` — same
  names/schemas as the original `TOOL_SCHEMAS`, so an existing proxy/system
  prompt tuned for those tool names keeps working unchanged.
- **UI** (`src/ui/`) — Ink-based: `Static` transcript so history never
  re-renders/flickers, a bordered multi-line `InputBox`, tool-call/result
  rendering, a todo/plan panel, and modal-style confirm/ask-user prompts.

Not carried over (flag if you want any of these rebuilt next, they're each
a separate, sizeable piece): the SQLite conversation memory + `/improve`
user-profile learning, the Telegram remote-control bridge, the MCP client,
and `run_subagent` (currently not wired to a nested agent instance).

"All other features like Claude Code" is a big, open-ended ask — the items
above (full-width input, markdown rendering, paste collapsing, auto/manual
permission modes, Esc-to-interrupt, output collapsing) are the concrete
Claude Code behaviors I could identify and implement this round. If there's
a specific other Claude Code behavior you're picturing (e.g. a `/compact`
context-summarizing command, file-diff previews before `edit_file` writes,
a persistent session log you can resume, syntax-highlighted diffs), tell me
which one and I'll build it next rather than guessing further.

## Note on environment

I wasn't able to run `npm install` / `tsc` in this sandbox (outbound
registry access is blocked here), so the build hasn't been compiled and
smoke-tested end-to-end. The code was written and reviewed carefully, but
please run `npm run build` on your machine and tell me about any type
errors or runtime issues — I'll fix them immediately.
