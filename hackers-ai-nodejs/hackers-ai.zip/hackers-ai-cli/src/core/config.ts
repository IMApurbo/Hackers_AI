import Conf from "conf";
import type { AgentConfig } from "../types.js";

// Persisted settings live in the OS config dir (e.g. ~/.config/hackers-ai-cli).
const store = new Conf<{ proxyBaseUrl: string; model: string }>({
  projectName: "hackers-ai-cli",
  defaults: {
    proxyBaseUrl: "http://localhost:8765",
    model: "deepseek-chat",
  },
});

function parseModeFlag(): "auto" | "manual" | null {
  const args = process.argv.slice(2);
  const i = args.indexOf("--mode");
  if (i !== -1 && args[i + 1] === "manual") return "manual";
  if (i !== -1 && args[i + 1] === "auto") return "auto";
  if (args.includes("--manual")) return "manual";
  if (args.includes("--auto")) return "auto";
  return null;
}

export function loadConfig(): AgentConfig {
  return {
    // env var wins, then persisted config, then default — same precedence
    // the original Python script used for HACKERS_AI_PROXY.
    proxyBaseUrl: process.env.HACKERS_AI_PROXY || store.get("proxyBaseUrl"),
    model: process.env.HACKERS_AI_MODEL || store.get("model"),
    cwd: process.cwd(),
    // Default is auto: the agent runs shell commands without asking, like
    // Claude Code's "bypass permissions" mode. Pass --mode manual (or just
    // --manual) to require a y/n confirmation before every run_shell call.
    mode: parseModeFlag() || "auto",
  };
}

export function setConfigValue(key: "proxyBaseUrl" | "model", value: string) {
  store.set(key, value);
}

export function getConfigPath(): string {
  return store.path;
}
