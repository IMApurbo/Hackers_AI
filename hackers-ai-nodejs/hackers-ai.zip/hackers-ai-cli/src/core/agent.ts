import { randomUUID } from "node:crypto";
import { ProxyClient } from "./proxyClient.js";
import { TOOL_SCHEMAS, executeTool, ToolContext } from "./tools.js";
import { previewOrLog } from "./outputLog.js";
import type { Message, TranscriptEvent } from "../types.js";

const MAX_AGENT_TURNS = 30;

const SYSTEM_PROMPT = `You are Hackers AI, an autonomous terminal agent running on the
user's Linux machine with full shell access via the run_shell tool. Prefer the
dedicated tools (read_file, write_file, edit_file, grep, glob) over run_shell
equivalents for file work — they're more reliable. Use update_todos for any
multi-step task so the user can follow your plan. Only call ask_user when you
are genuinely blocked on a decision only the user can make. Be concise in your
final answers; the user is watching a terminal, not reading a report.

When the user's message contains an "@path/to/file" token, that's them
pointing you at a specific file via the input box's file picker (like an
@-mention) — read that file with read_file before responding, even if the
rest of the message doesn't explicitly ask you to.`;

export interface AgentDeps {
  proxy: ProxyClient;
  cwd: string;
  emit: (event: TranscriptEvent) => void;
  confirmShell: (command: string) => Promise<boolean>;
  askUser: (question: string, options?: string[]) => Promise<string>;
  notify: (message: string) => void;
}

export class Agent {
  private messages: Message[] = [];

  constructor(private deps: AgentDeps) {}

  async send(userText: string, signal?: AbortSignal): Promise<void> {
    this.deps.emit({ kind: "user", text: userText, id: randomUUID() });
    this.messages.push({ role: "user", content: [{ type: "text", text: userText }] });

    const ctx: ToolContext = {
      cwd: this.deps.cwd,
      proxy: this.deps.proxy,
      confirmShell: this.deps.confirmShell,
      askUser: this.deps.askUser,
      onTodos: (todos) =>
        this.deps.emit({ kind: "todos", todos: todos as any, id: randomUUID() }),
      notify: (m) => this.deps.notify(m),
      signal,
    };

    for (let turn = 0; turn < MAX_AGENT_TURNS; turn++) {
      if (signal?.aborted) {
        this.deps.emit({ kind: "system", text: "Interrupted.", id: randomUUID() });
        return;
      }

      let resp;
      try {
        resp = await this.deps.proxy.askAgentic(
          this.messages,
          SYSTEM_PROMPT,
          TOOL_SCHEMAS as unknown as Record<string, any>[],
          signal
        );
      } catch (e: any) {
        if (signal?.aborted || e?.name === "AbortError") {
          this.deps.emit({ kind: "system", text: "Interrupted.", id: randomUUID() });
          return;
        }
        throw e;
      }

      const assistantContent = resp.content;
      this.messages.push({ role: "assistant", content: assistantContent as any });

      const toolCalls = assistantContent.filter((b) => b.type === "tool_use") as Extract<
        typeof assistantContent[number],
        { type: "tool_use" }
      >[];
      const textBlocks = assistantContent.filter((b) => b.type === "text") as Extract<
        typeof assistantContent[number],
        { type: "text" }
      >[];

      for (const t of textBlocks) {
        if (t.text.trim()) {
          this.deps.emit({ kind: "assistant", text: t.text, id: randomUUID() });
        }
      }

      if (toolCalls.length === 0) {
        return; // final answer for this turn — done
      }

      // Announce every call up front, then run them concurrently. Independent
      // tool calls the model batches into one turn (e.g. several run_shell /
      // read_file calls) no longer wait on each other — same idea as Claude
      // Code running independent tool calls in parallel within a turn.
      // Anthropic's tool_result ordering doesn't need to match issue order,
      // but we still emit UI events and push results back in the original
      // call order so the transcript and the message history stay readable.
      for (const call of toolCalls) {
        this.deps.emit({
          kind: "tool_call",
          name: call.name,
          input: call.input,
          id: call.id,
        });
      }

      const settled = await Promise.all(
        toolCalls.map((call) => executeTool(ctx, call.name, call.input))
      );

      const toolResults: Message["content"] = [];
      toolCalls.forEach((call, i) => {
        const result = settled[i];
        // The model always gets the full result; the terminal only shows a
        // preview (with a path to the full text) once it gets long — same
        // idea as Claude Code's output collapsing.
        this.deps.emit({
          kind: "tool_result",
          name: call.name,
          output: previewOrLog(result.output, call.name),
          isError: result.isError,
          // Must NOT reuse call.id: App.tsx's line cache is keyed by event
          // id+width, and if this matched the tool_call event's id above,
          // the tool_result would hit that cache entry and silently render
          // the tool_call's lines again instead of its own — which is
          // exactly the "tool call shows twice / output never shows" bug.
          id: `${call.id}:result`,
        });
        toolResults.push({
          type: "tool_result",
          tool_use_id: call.id,
          content: result.output,
          is_error: result.isError,
        });
      });
      this.messages.push({ role: "user", content: toolResults });
    }

    this.deps.emit({
      kind: "system",
      text: `Stopped after ${MAX_AGENT_TURNS} turns without a final answer.`,
      id: randomUUID(),
    });
  }

  reset(): void {
    this.messages = [];
  }
}
