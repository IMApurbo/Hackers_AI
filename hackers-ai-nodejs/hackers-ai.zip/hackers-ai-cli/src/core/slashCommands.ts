export interface SlashCommandSpec {
  name: string;
  usage: string;
  description: string;
}

export const SLASH_COMMANDS: SlashCommandSpec[] = [
  { name: "help", usage: "/help", description: "show available commands" },
  { name: "clear", usage: "/clear", description: "clear the transcript and reset context" },
  {
    name: "mode",
    usage: "/mode auto|manual",
    description: "toggle whether run_shell needs y/n confirmation",
  },
  { name: "model", usage: "/model <name>", description: "switch model (persisted)" },
  { name: "proxy", usage: "/proxy <url>", description: "switch proxy base URL (persisted)" },
  { name: "exit", usage: "/exit", description: "quit" },
];
