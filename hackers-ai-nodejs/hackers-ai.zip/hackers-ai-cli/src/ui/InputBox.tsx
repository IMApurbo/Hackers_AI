import React, { useEffect, useMemo, useRef, useState } from "react";
import fs from "node:fs";
import path from "node:path";
import { Box, Text, useInput, usePaste, useStdout } from "ink";
import { SLASH_COMMANDS } from "../core/slashCommands.js";

// ── @file mentions ──────────────────────────────────────────────────
// Two modes, mirroring Claude Code's `@` picker:
//   1. No "/" typed yet ("@foo")   → fuzzy-search file names anywhere in
//      the project (fast, cached recursive walk).
//   2. A "/" is present ("@src/",
//      "@../", "@../../lib/ut")     → browse that exact directory's
//      contents, so the user can drill into folders and back out again
//      with "../", "../../", etc. Selecting a folder keeps the mention
//      open (so you can keep drilling); selecting a file closes it.
const IGNORED_DIRS = new Set(["node_modules", ".git", "dist", "build", ".next", ".cache"]);
const MAX_FILES = 5000;
const MAX_DIR_ENTRIES = 500;
const CACHE_TTL_MS = 5000;

// -- mode 1: cached recursive walk, used for plain "@query" fuzzy search --
let fileCache: { cwd: string; files: string[]; builtAt: number } | null = null;

function walkForMentions(dir: string, base: string, out: string[]): void {
  if (out.length >= MAX_FILES) return;
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (out.length >= MAX_FILES) return;
    if (e.name.startsWith(".") && e.name !== ".env") continue;
    if (IGNORED_DIRS.has(e.name)) continue;
    const full = path.join(dir, e.name);
    const rel = path.relative(base, full);
    if (e.isDirectory()) {
      walkForMentions(full, base, out);
    } else {
      out.push(rel);
    }
  }
}

function getProjectFiles(cwd: string): string[] {
  const now = Date.now();
  if (fileCache && fileCache.cwd === cwd && now - fileCache.builtAt < CACHE_TTL_MS) {
    return fileCache.files;
  }
  const files: string[] = [];
  walkForMentions(cwd, cwd, files);
  fileCache = { cwd, files, builtAt: now };
  return files;
}

// -- mode 2: single-directory listing, used once the query contains "/" --
interface DirEntry {
  name: string;
  isDir: boolean;
}

const dirCache = new Map<string, { entries: DirEntry[]; builtAt: number }>();

function listDirEntries(absDir: string): DirEntry[] {
  const now = Date.now();
  const cached = dirCache.get(absDir);
  if (cached && now - cached.builtAt < CACHE_TTL_MS) return cached.entries;

  let dirents: fs.Dirent[];
  try {
    dirents = fs.readdirSync(absDir, { withFileTypes: true });
  } catch {
    dirCache.set(absDir, { entries: [], builtAt: now });
    return [];
  }
  const out: DirEntry[] = [];
  for (const e of dirents) {
    if (out.length >= MAX_DIR_ENTRIES) break;
    if (e.name.startsWith(".") && e.name !== ".env") continue;
    if (IGNORED_DIRS.has(e.name)) continue;
    out.push({ name: e.name, isDir: e.isDirectory() });
  }
  out.sort((a, b) => (a.isDir === b.isDir ? a.name.localeCompare(b.name) : a.isDir ? -1 : 1));
  dirCache.set(absDir, { entries: out, builtAt: now });
  return out;
}

/** A single row in the @ suggestion list, regardless of which mode built it. */
interface Mention {
  /** What's shown in the picker, e.g. "src/ui/" or "src/ui/App.tsx". */
  display: string;
  /** What replaces the in-progress "@query" when chosen (no leading "@"). */
  insert: string;
  isDir: boolean;
}

/** Finds an in-progress "@query" token ending at the cursor (end of value),
 * so suggestions only show while actively typing a mention. */
function activeMentionQuery(value: string): string | null {
  const at = value.lastIndexOf("@");
  if (at === -1) return null;
  const tail = value.slice(at + 1);
  if (tail.includes(" ") || tail.includes("\n") || tail.includes("@")) return null;
  return tail;
}

function buildMentions(query: string, cwd: string): Mention[] {
  const slash = query.lastIndexOf("/");

  if (slash === -1) {
    // Mode 1: fuzzy search by filename anywhere in the project.
    const files = getProjectFiles(cwd);
    const q = query.toLowerCase();
    const scored = files
      .filter((f) => f.toLowerCase().includes(q))
      .map((f) => {
        const base = path.basename(f).toLowerCase();
        // Prefix-of-basename matches float to the top, like Claude Code's picker.
        const score = base.startsWith(q) ? 0 : f.toLowerCase().indexOf(q);
        return { f, score };
      })
      .sort((a, b) => a.score - b.score || a.f.length - b.f.length)
      .slice(0, 8);
    return scored.map(({ f }) => ({ display: f, insert: f, isDir: false }));
  }

  // Mode 2: browse the exact directory the user has typed, e.g.
  // "src/ui/Inp" -> list src/ui/, filtered to entries starting with "Inp".
  // "../../" -> list two levels above cwd.
  const dirPart = query.slice(0, slash);
  const prefix = query.slice(slash + 1).toLowerCase();
  const absDir = path.resolve(cwd, dirPart || ".");
  const entries = listDirEntries(absDir);

  const rows: Mention[] = [];
  if ("..".startsWith(prefix)) {
    rows.push({ display: "../", insert: `${dirPart}/..`, isDir: true });
  }
  for (const e of entries) {
    if (!e.name.toLowerCase().startsWith(prefix)) continue;
    const insert = `${dirPart}/${e.name}`;
    rows.push({ display: e.isDir ? `${insert}/` : insert, insert, isDir: e.isDir });
  }
  return rows.slice(0, 10);
}

interface Props {
  onSubmit: (value: string) => void;
  history: string[];
  disabled?: boolean;
  placeholder?: string;
  promptLabel?: string;
  /** Working directory to search for @-mentioned files. Defaults to process.cwd(). */
  cwd?: string;
  /** Called whenever the total rendered height of this box (including its
   * slash-command / @-mention popovers) changes, in terminal rows — lets
   * the parent reserve exactly enough space for it above. */
  onHeightChange?: (rows: number) => void;
}

// Large / multi-line pastes are collapsed into a short placeholder in the
// visible input (same idea as Claude Code) so the box doesn't balloon to
// hundreds of lines; the real text is swapped back in right before submit.
const PASTE_CHAR_THRESHOLD = 400;
const pasteStore = new Map<string, string>();
let pasteCounter = 0;

function makePlaceholder(text: string): string {
  pasteCounter += 1;
  const lines = text.split("\n").length;
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const placeholder = `[Pasted text: ${lines} line${lines === 1 ? "" : "s"}, ${words} word${
    words === 1 ? "" : "s"
  } #${pasteCounter}]`;
  pasteStore.set(placeholder, text);
  return placeholder;
}

function expandPastes(s: string): string {
  let out = s;
  for (const [placeholder, text] of pasteStore) {
    out = out.split(placeholder).join(text);
  }
  return out;
}

export default function InputBox({
  onSubmit,
  history,
  disabled,
  placeholder = "Type a message, or /help for commands…",
  promptLabel = "›",
  cwd = process.cwd(),
  onHeightChange,
}: Props) {
  const [value, setValue] = useState("");
  const [historyIndex, setHistoryIndex] = useState<number | null>(null);
  const [suggestIndex, setSuggestIndex] = useState(0);
  const { stdout } = useStdout();
  const columns = stdout?.columns ?? 80;

  const matches = useMemo(() => {
    if (!value.startsWith("/") || value.includes(" ") || value.includes("\n")) return [];
    const q = value.slice(1).toLowerCase();
    return SLASH_COMMANDS.filter((c) => c.name.startsWith(q));
  }, [value]);

  const mentionQuery = useMemo(() => activeMentionQuery(value), [value]);

  const fileMatches = useMemo(() => {
    if (mentionQuery === null) return [];
    return buildMentions(mentionQuery, cwd);
  }, [mentionQuery, cwd]);

  const showingFileSuggestions = fileMatches.length > 0;

  useEffect(() => {
    setSuggestIndex(0);
  }, [value]);

  // Ink puts the terminal into bracketed-paste mode for the lifetime of this
  // hook and hands back the ENTIRE pasted string in one call, no matter how
  // large it is or how many chunks the terminal/OS split it into — this is
  // what makes big copy-pastes actually work, matching Claude Code.
  usePaste(
    (text) => {
      if (disabled) return;
      if (text.length > PASTE_CHAR_THRESHOLD || text.includes("\n")) {
        setValue((v) => v + makePlaceholder(text));
      } else {
        setValue((v) => v + text);
      }
    },
    { isActive: !disabled }
  );

  useInput(
    (input, key) => {
      if (disabled) return;

      const showingSuggestions = matches.length > 0;

      if (showingSuggestions && key.tab) {
        setValue(`/${matches[Math.min(suggestIndex, matches.length - 1)].name} `);
        return;
      }
      if (showingSuggestions && key.upArrow) {
        setSuggestIndex((i) => Math.max(0, i - 1));
        return;
      }
      if (showingSuggestions && key.downArrow) {
        setSuggestIndex((i) => Math.min(matches.length - 1, i + 1));
        return;
      }

      // @-file mentions: Tab or Enter accepts the highlighted entry. Picking
      // a directory inserts "path/" and keeps the mention open so the user
      // can keep drilling in (or type "../" to back out); picking a file
      // inserts "path " and closes the mention, same as the slash-command
      // picker above.
      if (showingFileSuggestions && (key.tab || key.return) && !key.shift && !key.meta) {
        const at = value.lastIndexOf("@");
        const chosen = fileMatches[Math.min(suggestIndex, fileMatches.length - 1)];
        const inserted = chosen.isDir ? `${chosen.insert}/` : `${chosen.insert} `;
        setValue(value.slice(0, at + 1) + inserted);
        return;
      }
      if (showingFileSuggestions && key.upArrow) {
        setSuggestIndex((i) => Math.max(0, i - 1));
        return;
      }
      if (showingFileSuggestions && key.downArrow) {
        setSuggestIndex((i) => Math.min(fileMatches.length - 1, i + 1));
        return;
      }
      if (showingFileSuggestions && key.escape) {
        // Bail out of the mention (a trailing space ends the "@query" match)
        // without closing the whole input box.
        setValue((v) => v + " ");
        return;
      }

      if (key.return) {
        if (key.shift || key.meta) {
          setValue((v) => v + "\n");
          return;
        }
        const trimmed = value.trim();
        if (trimmed) onSubmit(expandPastes(trimmed));
        setValue("");
        setHistoryIndex(null);
        return;
      }

      if (key.ctrl && input === "j") {
        setValue((v) => v + "\n");
        return;
      }

      // Plain ↑/↓ scroll the transcript now (see App.tsx) — and, in most
      // terminals, that's also what the mouse wheel sends while an app is
      // on the alt screen (the "alternate scroll" feature vim/less/htop
      // rely on for wheel support without implementing mouse reporting
      // themselves). Recall stays available on Ctrl+↑/Ctrl+↓ instead.
      if (key.upArrow && key.ctrl && value === "") {
        if (history.length === 0) return;
        const idx = historyIndex === null ? history.length - 1 : Math.max(0, historyIndex - 1);
        setHistoryIndex(idx);
        setValue(history[idx]);
        return;
      }

      if (key.downArrow && key.ctrl && historyIndex !== null) {
        const idx = historyIndex + 1;
        if (idx >= history.length) {
          setHistoryIndex(null);
          setValue("");
        } else {
          setHistoryIndex(idx);
          setValue(history[idx]);
        }
        return;
      }

      if (key.backspace || key.delete) {
        setValue((v) => {
          // A pasted-text placeholder like "[Pasted text: 1 line, 125
          // words #3]" is an opaque token standing in for the real
          // clipboard content stored in pasteStore. Deleting it one
          // character at a time (the old behavior) breaks the exact-string
          // match expandPastes relies on, leaving mangled bracket text in
          // the input that doesn't turn back into the pasted content on
          // submit. So: if the value ends with a complete placeholder,
          // remove the whole thing in one keystroke and drop it from the
          // store; otherwise just remove the last character as normal.
          const placeholderMatch = v.match(/\[Pasted text: \d+ lines?, \d+ words? #\d+\]$/);
          if (placeholderMatch) {
            pasteStore.delete(placeholderMatch[0]);
            return v.slice(0, v.length - placeholderMatch[0].length);
          }
          return v.slice(0, -1);
        });
        return;
      }

      if (key.ctrl && input === "u") {
        setValue("");
        return;
      }

      // Typed (non-paste) characters only reach here — usePaste intercepts
      // pasted text on its own event channel above, so this never has to
      // guess whether a given chunk was typed or pasted.
      if (!key.ctrl && !key.meta && input) {
        setValue((v) => v + input);
      }
    },
    { isActive: !disabled }
  );

  const lines = value.length ? value.split("\n") : [""];

  // Report our total rendered height (popovers + bordered input box) so
  // the parent can reserve exactly this many rows for the live area.
  const slashPanelRows = matches.length > 0 && !disabled ? matches.length + 3 : 0;
  const mentionPanelRows = showingFileSuggestions && !disabled ? fileMatches.length + 3 : 0;
  const inputBoxRows = 2 + lines.length; // border top + bottom, plus content lines
  const totalRows = slashPanelRows + mentionPanelRows + inputBoxRows;
  const lastReportedRef = useRef<number | null>(null);
  useEffect(() => {
    if (lastReportedRef.current !== totalRows) {
      lastReportedRef.current = totalRows;
      onHeightChange?.(totalRows);
    }
  }, [totalRows, onHeightChange]);

  return (
    <Box flexDirection="column" width={columns}>
      {matches.length > 0 && !disabled && (
        <Box flexDirection="column" borderStyle="round" borderColor="gray" paddingX={1}>
          {matches.map((c, i) => (
            <Text key={c.name} color={i === suggestIndex ? "cyan" : undefined}>
              {i === suggestIndex ? "❯ " : "  "}
              <Text bold={i === suggestIndex}>{c.usage}</Text>
              <Text dimColor>{"  " + c.description}</Text>
            </Text>
          ))}
          <Text dimColor>Tab to complete · ↑↓ to select · Enter to run as typed</Text>
        </Box>
      )}
      {showingFileSuggestions && !disabled && (
        <Box flexDirection="column" borderStyle="round" borderColor="gray" paddingX={1}>
          {fileMatches.map((f, i) => (
            <Text key={f.display} color={i === suggestIndex ? "cyan" : f.isDir ? "blue" : undefined}>
              {i === suggestIndex ? "❯ " : "  "}
              {f.display}
            </Text>
          ))}
          <Text dimColor>Tab/Enter to select · ↑↓ to move · Esc to keep typing</Text>
        </Box>
      )}
      <Box
        borderStyle="round"
        borderColor={disabled ? "gray" : "cyan"}
        paddingX={1}
        flexDirection="column"
      >
        {lines.map((line, i) => (
          <Box key={i}>
            <Text color={disabled ? "gray" : "cyan"} bold>
              {i === 0 ? `${promptLabel} ` : "  "}
            </Text>
            <Text dimColor={!line && value === ""}>
              {line || (i === 0 ? placeholder : "")}
            </Text>
            {i === lines.length - 1 && !disabled ? <Text color="cyan">▏</Text> : null}
          </Box>
        ))}
      </Box>
    </Box>
  );
}
