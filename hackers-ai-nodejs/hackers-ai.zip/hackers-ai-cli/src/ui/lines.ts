import chalk from "chalk";
import wrapAnsi from "wrap-ansi";
import type { TranscriptEvent } from "../types.js";
import { renderMarkdown } from "./markdown.js";

// ── scrollback line model ────────────────────────────────────────────
// We render the full-screen transcript ourselves (see App.tsx) instead of
// handing the whole thing to Ink's layout engine, so we can scroll it with
// PageUp/PageDown/Home/End inside the alternate screen buffer. That means
// every event has to be turned into the exact array of terminal rows Ink
// *would* have produced for it, so scrolling never looks different from
// the live view.
//
// `wrapAnsi(text, width, { trim: false, hard: true })` is the same call
// Ink's own <Text wrap="wrap"> makes internally (see ink/build/wrap-text.js),
// so wrapping here lines up with wrapping there. Colors are baked in with
// chalk using the same named-color lookup Ink's colorize() uses
// (`chalk[color](str)`), so a plain string is enough — no per-line style
// props needed when rendering the slice.
function wrapLine(text: string, width: number): string[] {
  const safeWidth = Math.max(1, width);
  return wrapAnsi(text, safeWidth, { trim: false, hard: true }).split("\n");
}

function summarizeInput(name: string, input: Record<string, any>): string {
  switch (name) {
    case "run_shell":
      return input.command;
    case "read_file":
      return input.path;
    case "write_file":
      return input.path;
    case "edit_file":
      return `${input.path} — ${input.instruction}`;
    case "grep":
      return `"${input.pattern}" in ${input.path || "."}`;
    case "glob":
      return input.pattern;
    case "web_fetch":
      return input.url;
    case "notify_user":
      return input.message;
    default:
      return JSON.stringify(input).slice(0, 100);
  }
}

/** Renders one transcript event into the exact terminal rows it occupies
 * at the given width — a direct line-for-line mirror of Message.tsx. */
export function eventToLines(event: TranscriptEvent, width: number): string[] {
  switch (event.kind) {
    case "user": {
      const line = chalk.green.bold(`› ${event.text}`);
      return ["", ...wrapLine(line, width)];
    }

    case "assistant": {
      // renderMarkdown already reflows to the terminal width itself, so no
      // further wrapping is needed here (and re-wrapping already-wrapped
      // ANSI text risks double-breaking it).
      const rendered = renderMarkdown(event.text);
      return ["", ...rendered.split("\n")];
    }

    case "tool_call": {
      const inner =
        "⏺ " + chalk.bold(event.name) + chalk.dim("  " + summarizeInput(event.name, event.input));
      return ["", ...wrapLine(chalk.magenta(inner), width)];
    }

    case "tool_result": {
      const prefix = event.isError ? "✗ " : "⎿ ";
      const body = event.output.trim() || "(empty)";
      const colored = chalk[event.isError ? "red" : "gray"](prefix + body);
      return wrapLine(colored, Math.max(1, width - 2)).map((l) => "  " + l);
    }

    case "todos": {
      const out = ["", chalk.cyan.bold("Plan")];
      for (const t of event.todos) {
        const marker = t.status === "completed" ? "  ✓ " : t.status === "in_progress" ? "  ▸ " : "  ○ ";
        const text = t.status === "pending" ? chalk.dim(t.text) : t.text;
        out.push(...wrapLine(marker + text, width));
      }
      return out;
    }

    case "system": {
      return ["", ...wrapLine(chalk.yellow(event.text), width)];
    }

    default:
      return [];
  }
}
