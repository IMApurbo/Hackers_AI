import React, { useCallback, useMemo, useRef, useState } from "react";
import { randomUUID } from "node:crypto";
import { Box, Text, useApp, useInput, usePaste, useStdout } from "ink";
import Spinner from "ink-spinner";
import InputBox from "./InputBox.js";
import { Agent } from "../core/agent.js";
import { ProxyClient } from "../core/proxyClient.js";
import type { AgentConfig, PermissionMode, TranscriptEvent } from "../types.js";
import { setConfigValue } from "../core/config.js";
import { SLASH_COMMANDS } from "../core/slashCommands.js";
import { eventToLines } from "./lines.js";
import wrapAnsi from "wrap-ansi";

/** How many terminal rows `text` will take up when wrapped to `width` —
 * used to size the confirm/ask panels so the scrollback viewport below
 * reserves exactly enough space for them. */
function wrapAnsiLineCount(text: string, width: number): number {
  return wrapAnsi(text, Math.max(1, width), { trim: false, hard: true }).split("\n").length;
}

type Mode =
  | { kind: "idle" }
  | { kind: "busy"; label: string }
  | { kind: "confirm"; command: string; resolve: (ok: boolean) => void }
  | {
      kind: "ask";
      question: string;
      options?: string[];
      resolve: (answer: string) => void;
      draft: string;
    };

export default function App({ config }: { config: AgentConfig }) {
  const { exit } = useApp();
  const { stdout } = useStdout();
  const columns = stdout?.columns ?? 80;
  const rows = stdout?.rows ?? 24;
  const [events, setEvents] = useState<TranscriptEvent[]>([]);
  const [history, setHistory] = useState<string[]>([]);
  const [mode, setMode] = useState<Mode>({ kind: "idle" });
  // How many terminal rows the InputBox (plus its suggestion popovers) is
  // currently occupying, reported up so the transcript viewport below can
  // reserve exactly enough space and never gets pushed off-screen.
  const [inputHeight, setInputHeight] = useState(3);
  // ── scrollback ──────────────────────────────────────────────────
  // We're in the alt screen buffer (see index.tsx), which has no native
  // scrollback, so the transcript is windowed and paged ourselves:
  // `scrollOffset` counts terminal rows scrolled up from the live bottom.
  // 0 means "pinned to the latest message" (the normal, auto-following
  // state); a positive value freezes the view that many rows into the
  // past so new messages arriving don't yank the view out from under
  // someone reading back through history.
  const [scrollOffset, setScrollOffset] = useState(0);
  const lineCacheRef = useRef(new Map<string, { width: number; lines: string[] }>());
  const [permMode, setPermMode] = useState<PermissionMode>(config.mode);
  const proxy = useMemo(() => new ProxyClient(config.proxyBaseUrl, config.model), [config]);
  const agentRef = useRef<Agent | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  // permMode changes at runtime (via /mode); confirmShell reads the latest
  // value through this ref so the closure captured by Agent stays current.
  const permModeRef = useRef(permMode);
  permModeRef.current = permMode;
  // With tool calls now running in parallel, more than one run_shell inside
  // the same turn can ask for confirmation at once. Only one confirm modal
  // can be on screen, so extra requests wait here and get shown one at a
  // time as each is resolved.
  const confirmQueueRef = useRef<{ command: string; resolve: (ok: boolean) => void }[]>([]);

  const emit = useCallback((event: TranscriptEvent) => {
    setEvents((prev) => [...prev, event]);
  }, []);

  const pumpConfirmQueue = useCallback(() => {
    const next = confirmQueueRef.current.shift();
    if (next) {
      setMode({ kind: "confirm", command: next.command, resolve: next.resolve });
    }
  }, []);

  const confirmShell = useCallback(
    (command: string) =>
      new Promise<boolean>((resolve) => {
        if (permModeRef.current === "auto") {
          resolve(true);
          return;
        }
        setMode((current) => {
          if (current.kind === "confirm") {
            // A confirm is already showing — queue this one behind it.
            confirmQueueRef.current.push({ command, resolve });
            return current;
          }
          return { kind: "confirm", command, resolve };
        });
      }),
    []
  );

  const askUser = useCallback(
    (question: string, options?: string[]) =>
      new Promise<string>((resolve) => {
        setMode({ kind: "ask", question, options, resolve, draft: "" });
      }),
    []
  );

  const notify = useCallback(() => {
    stdout?.write("\u0007"); // terminal bell
  }, [stdout]);

  if (!agentRef.current) {
    agentRef.current = new Agent({ proxy, cwd: config.cwd, emit, confirmShell, askUser, notify });
  }

  const runSlash = useCallback(
    (cmd: string) => {
      const [name, ...rest] = cmd.slice(1).split(" ");
      const arg = rest.join(" ").trim();
      switch (name) {
        case "help":
          emit({
            kind: "system",
            id: randomUUID(),
            text:
              SLASH_COMMANDS.map((c) => `${c.usage.padEnd(20)} ${c.description}`).join("\n") +
              "\n\n" +
              "Esc (while busy)   interrupt the current turn\n" +
              "Ctrl+J             insert a newline without submitting\n" +
              "Tab (after /)      complete the highlighted slash command\n" +
              "↑ / ↓, wheel       scroll the transcript one line\n" +
              "PageUp / PageDown  scroll the transcript one page\n" +
              "Home / End         jump to the oldest / latest message\n" +
              "Ctrl+↑ / Ctrl+↓    recall previous prompts (when input is empty)",
          });
          break;
        case "clear":
          setEvents([]);
          agentRef.current?.reset();
          break;
        case "mode":
          if (arg === "auto" || arg === "manual") {
            setPermMode(arg);
            emit({
              kind: "system",
              id: randomUUID(),
              text: `Mode set to ${arg}${arg === "auto" ? " — run_shell will not ask for confirmation." : " — run_shell will ask for confirmation."}`,
            });
          } else {
            emit({ kind: "system", id: randomUUID(), text: `Current mode: ${permModeRef.current}. Usage: /mode auto|manual` });
          }
          break;
        case "model":
          if (arg) {
            setConfigValue("model", arg);
            emit({ kind: "system", id: randomUUID(), text: `Model set to ${arg} (restart to apply).` });
          }
          break;
        case "proxy":
          if (arg) {
            setConfigValue("proxyBaseUrl", arg);
            emit({ kind: "system", id: randomUUID(), text: `Proxy set to ${arg} (restart to apply).` });
          }
          break;
        case "exit":
        case "quit":
          exit();
          break;
        default:
          emit({ kind: "system", id: randomUUID(), text: `Unknown command: /${name}` });
      }
    },
    [emit, exit]
  );

  const handleSubmit = useCallback(
    async (text: string) => {
      // Sending a message always jumps back to the live view — nobody
      // wants to type something and have it appear off-screen above
      // wherever they'd scrolled to.
      setScrollOffset(0);
      setHistory((h) => [...h, text]);
      if (text.startsWith("/")) {
        runSlash(text);
        return;
      }
      const controller = new AbortController();
      abortRef.current = controller;
      setMode({ kind: "busy", label: "Thinking (Esc to interrupt)" });
      try {
        await agentRef.current!.send(text, controller.signal);
      } catch (e: any) {
        if (e?.name !== "AbortError") {
          emit({ kind: "system", id: randomUUID(), text: `Error: ${e?.message ?? e}` });
        }
      } finally {
        abortRef.current = null;
        setMode({ kind: "idle" });
      }
    },
    [emit, runSlash]
  );

  // Free-text "/ask" prompts (e.g. a tool asking a clarifying question) get
  // the same reliable large-paste handling as the main input box — without
  // this, pasting anything big here would get chopped up across multiple
  // useInput callbacks instead of landing as one string.
  usePaste(
    (text) => {
      setMode((m) => (m.kind === "ask" && !m.options ? { ...m, draft: m.draft + text } : m));
    },
    { isActive: mode.kind === "ask" && !mode.options }
  );

  // ── scrollback viewport ──────────────────────────────────────────
  // Turn every event into the rows it occupies (cached per event id+width
  // so a long session doesn't re-wrap its entire history on every
  // keystroke), then work out how many of the trailing rows fit below the
  // live area (mode panel + input box + footer) and slice that window out.
  const panelWidth = Math.max(1, columns - 4);
  const modePanelHeight =
    mode.kind === "confirm"
      ? 1 + 2 + 1 + wrapAnsiLineCount(mode.command, panelWidth) + 1
      : mode.kind === "ask"
        ? 1 + 2 + wrapAnsiLineCount(mode.question, panelWidth) + (mode.options ? mode.options.length : 1)
        : mode.kind === "busy"
          ? 1 + 1
          : 0;
  const footerHeight = 1;
  const inputMarginTop = 1;
  const reservedRows = modePanelHeight + inputMarginTop + inputHeight + footerHeight;

  const allLines = useMemo(() => {
    const cache = lineCacheRef.current;
    const seen = new Set<string>();
    const out: string[] = [];
    for (const event of events) {
      seen.add(event.id);
      const cached = cache.get(event.id);
      const lines =
        cached && cached.width === columns ? cached.lines : eventToLines(event, columns);
      cache.set(event.id, { width: columns, lines });
      out.push(...lines);
    }
    // Drop cache entries for events that no longer exist (e.g. after /clear).
    for (const id of cache.keys()) {
      if (!seen.has(id)) cache.delete(id);
    }
    return out;
  }, [events, columns]);

  const scrolled = scrollOffset > 0;
  const viewportRows = Math.max(3, rows - reservedRows - (scrolled ? 1 : 0));
  const total = allLines.length;
  const maxScroll = Math.max(0, total - viewportRows);
  const clampedOffset = Math.min(scrollOffset, maxScroll);
  const endIdx = total - clampedOffset;
  const startIdx = Math.max(0, endIdx - viewportRows);
  const visibleLines = allLines.slice(startIdx, endIdx);

  // ── modal / interrupt / scroll key handling ───────────────────
  useInput(
    (input, key) => {
      // Plain ↑/↓ scroll one line at a time. This is the binding that
      // matters most: most terminal emulators run an "alternate scroll"
      // feature that turns mouse wheel / trackpad scrolling into ↑/↓ key
      // presses while an app is on the alt screen buffer (it's how vim,
      // less, and htop get wheel support without doing their own mouse
      // reporting) — so this one binding is what makes both the arrow
      // keys *and* the mouse wheel work.
      if (key.upArrow) {
        setScrollOffset((o) => Math.min(maxScroll, o + 1));
        return;
      }
      if (key.downArrow) {
        setScrollOffset((o) => Math.max(0, o - 1));
        return;
      }
      if (key.pageUp) {
        setScrollOffset((o) => Math.min(maxScroll, o + viewportRows));
        return;
      }
      if (key.pageDown) {
        setScrollOffset((o) => Math.max(0, o - viewportRows));
        return;
      }
      if (key.home) {
        setScrollOffset(maxScroll);
        return;
      }
      if (key.end) {
        setScrollOffset(0);
        return;
      }
      if (mode.kind === "busy") {
        if (key.escape) {
          abortRef.current?.abort();
        }
        return;
      }
      if (mode.kind === "confirm") {
        if (input.toLowerCase() === "y" || key.return) {
          mode.resolve(true);
          if (confirmQueueRef.current.length > 0) pumpConfirmQueue();
          else setMode({ kind: "busy", label: "Running (Esc to interrupt)" });
        } else if (input.toLowerCase() === "n" || key.escape) {
          mode.resolve(false);
          if (confirmQueueRef.current.length > 0) pumpConfirmQueue();
          else setMode({ kind: "busy", label: "Thinking (Esc to interrupt)" });
        }
      } else if (mode.kind === "ask" && !mode.options) {
        if (key.return) {
          mode.resolve(mode.draft);
          setMode({ kind: "busy", label: "Thinking (Esc to interrupt)" });
        } else if (key.backspace || key.delete) {
          setMode({ ...mode, draft: mode.draft.slice(0, -1) });
        } else if (!key.ctrl && !key.meta && input) {
          setMode({ ...mode, draft: mode.draft + input });
        }
      } else if (mode.kind === "ask" && mode.options) {
        const n = parseInt(input, 10);
        if (!isNaN(n) && n >= 1 && n <= mode.options.length) {
          mode.resolve(mode.options[n - 1]);
          setMode({ kind: "busy", label: "Thinking (Esc to interrupt)" });
        }
      }
    },
    // Always active (not just during confirm/ask/busy) so PageUp/PageDown/
    // Home/End can scroll the transcript back while idle and typing, too.
    { isActive: true }
  );

  return (
    <Box flexDirection="column">
      {scrolled && (
        <Box>
          <Text dimColor>
            ── scrolled up · {startIdx} line{startIdx === 1 ? "" : "s"} above · PageDown/End to
            return to live ──
          </Text>
        </Box>
      )}
      <Box flexDirection="column" height={viewportRows} overflow="hidden">
        {visibleLines.map((line, i) => (
          <Text key={startIdx + i}>{line || " "}</Text>
        ))}
      </Box>

      {mode.kind === "confirm" && (
        <Box marginTop={1} flexDirection="column" borderStyle="round" borderColor="yellow" paddingX={1} width={columns}>
          <Text color="yellow" bold>
            Run this command?
          </Text>
          <Text>{mode.command}</Text>
          <Text dimColor>[y] yes   [n] no   (switch to /mode auto to stop asking)</Text>
        </Box>
      )}

      {mode.kind === "ask" && (
        <Box marginTop={1} flexDirection="column" borderStyle="round" borderColor="blue" paddingX={1} width={columns}>
          <Text color="blue" bold>
            {mode.question}
          </Text>
          {mode.options ? (
            mode.options.map((o, i) => (
              <Text key={i}>
                {"  "}[{i + 1}] {o}
              </Text>
            ))
          ) : (
            <Text>
              {"> "}
              {mode.draft}
              <Text color="blue">▏</Text>
            </Text>
          )}
        </Box>
      )}

      {mode.kind === "busy" && (
        <Box marginTop={1}>
          <Text color="magenta">
            <Spinner type="dots" /> {mode.label}…
          </Text>
        </Box>
      )}

      <Box marginTop={1}>
        <InputBox
          onSubmit={handleSubmit}
          history={history}
          disabled={mode.kind !== "idle"}
          cwd={config.cwd}
          onHeightChange={setInputHeight}
        />
      </Box>

      <Box>
        <Text dimColor>
          {config.model} · {config.proxyBaseUrl} · mode:{permMode}
          {permMode === "auto" ? " (no confirm)" : ""} · {config.cwd}
        </Text>
      </Box>
    </Box>
  );
}
