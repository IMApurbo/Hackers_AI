#!/usr/bin/env node
import React from "react";
import { render } from "ink";
import chalk from "chalk";
import App from "./ui/App.js";
import { loadConfig } from "./core/config.js";
import { ProxyClient } from "./core/proxyClient.js";

// ── full-terminal takeover ──────────────────────────────────────────
// Same trick vim/htop use: switch to the terminal's alternate screen
// buffer so our output lives on its own canvas instead of scrolling into
// the user's normal history, and hide the (Ink-drawn) cursor. Both are
// restored on every exit path — normal completion, /exit, Ctrl+C, a
// signal, or a crash — so the user's shell is left exactly as it was.
//
// The alt screen buffer has no scrollback of its own, so unlike a plain
// terminal app we can't lean on the terminal's native mouse-wheel/
// Shift+PageUp scrolling to review older messages — App.tsx renders the
// whole transcript itself and implements its own PageUp/PageDown/Home/End
// scrolling over it (see the scrollback section there) so history is
// still fully browsable while the screen stays fixed.
const ENTER_ALT_SCREEN = "\x1b[?1049h";
const LEAVE_ALT_SCREEN = "\x1b[?1049l";
const HIDE_CURSOR = "\x1b[?25l";
const SHOW_CURSOR = "\x1b[?25h";

let restored = false;
function restoreTerminal() {
  if (restored) return;
  restored = true;
  process.stdout.write(SHOW_CURSOR + LEAVE_ALT_SCREEN);
}

async function main() {
  const config = loadConfig();

  process.stdout.write(ENTER_ALT_SCREEN + HIDE_CURSOR);
  process.on("exit", restoreTerminal);
  process.on("SIGINT", () => {
    restoreTerminal();
    process.exit(130);
  });
  process.on("SIGTERM", () => {
    restoreTerminal();
    process.exit(143);
  });
  process.on("uncaughtException", (err) => {
    restoreTerminal();
    console.error(err);
    process.exit(1);
  });

  console.log(
    chalk.cyan.bold(`
  ╭──────────────────────────────────────────╮
  │   Hackers AI · terminal agent             │
  ╰──────────────────────────────────────────╯`)
  );
  console.log(chalk.dim(`  model  : ${config.model}`));
  console.log(chalk.dim(`  proxy  : ${config.proxyBaseUrl}`));
  console.log(chalk.dim(`  cwd    : ${config.cwd}`));
  console.log(
    config.mode === "auto"
      ? chalk.green(`  mode   : auto (commands run without asking — pass --mode manual to confirm each one)\n`)
      : chalk.yellow(`  mode   : manual (every run_shell call needs y/n confirmation)\n`)
  );

  const proxy = new ProxyClient(config.proxyBaseUrl, config.model);
  const ok = await proxy.health();
  if (!ok) {
    console.log(
      chalk.yellow(
        `  [!] Could not reach the proxy at ${config.proxyBaseUrl}.\n` +
          `      Start your local server (e.g. \`python server.py\`) first,\n` +
          `      or point elsewhere with HACKERS_AI_PROXY=<url> / \`/proxy <url>\`.\n`
      )
    );
  } else {
    console.log(chalk.green(`  [✓] Proxy reachable\n`));
  }

  const instance = render(<App config={config} />);
  await instance.waitUntilExit();
  restoreTerminal();
}

main().catch((err) => {
  restoreTerminal();
  console.error(err);
  process.exit(1);
});
